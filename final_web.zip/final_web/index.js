function sendEmail(alamatEmail){
    Email.send({
        Host: "smtp.gmail.com",
        Username : "FAHOVEORGANIZATION@gmail.com",
        Password : "1234567",
        To : 'FAHOVEORGANIZATION@gmail.com',
        From : alamatEmail,
        Subject : "Subscription to Newsletter",
        Body : "This email agreed to subscribe to INFORMIT NEWSLETTER",
    }).then(
        message => alert("mail sent successfully")
    );
        
        
    
}