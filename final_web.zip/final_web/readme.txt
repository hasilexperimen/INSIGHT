https://hub.labs.coursera.org:443/connect/sharedlztadfjt?forceRefresh=false&path=%2F&isLabVersioning=true
http://uis.atwebpages.com/INSIGHT/index.html